# Animated Form

A Pen created on CodePen.io. Original URL: [https://codepen.io/frontendmax/pen/RazXVb](https://codepen.io/frontendmax/pen/RazXVb).

Registration form with pure CSS animations. Idea by <a href='https://dribbble.com/galshir'>Gal Shir</a>.